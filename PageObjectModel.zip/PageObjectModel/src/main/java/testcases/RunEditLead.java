package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificationMethods;
import pages.LoginPage;

public class RunEditLead extends ProjectSpecificationMethods{
	
	@BeforeTest
	public void setUp() {
		fileName = "EditLead";
	}
	
	@Test(dataProvider = "getData")
	public void runEdit(String phone, String company) throws InterruptedException {
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickOnLeads()
		.clickFindLead()
		.clickPhone()
		.typePhone(phone)
		.clickFind()
		.clickFirstElement()
		.clickOnEdit()
		.updateCompanyName(company)
		.clickOnSubmit()
		.verifyTitle();
		
		
		}
}
