package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificationMethods;
import pages.LoginPage;

public class RunDuplicateLead extends ProjectSpecificationMethods{

	@BeforeTest
	public void setUp() {
		fileName = "DuplicateLead";
	}
	
	@Test(dataProvider = "getData")
	public void runDuplicate(String company, String firstname, String lastname, String department) {
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickOnLeads()
		.clickCreateLead()
		.enterCompanyname(company)
		.enterFirstname(firstname)
		.enterLastname(lastname)
		.enterDepartmentname(department)
		.clickCreateLeadButton()
		.clickDuplicate()
		.typeCompanyName()
		.typeFirstName()
		.clickSubmit()
		.verifyTitle();
	}
	
}
