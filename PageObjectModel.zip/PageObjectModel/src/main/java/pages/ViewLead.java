package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificationMethods;

public class ViewLead extends ProjectSpecificationMethods{
	
	public ViewLead(ChromeDriver driver) {
		this.driver = driver;
	}
	
	String expTitle = "View Lead | opentaps CRM";
	public void verifyTitle() {
		String title = driver.getTitle();
		Assert.assertEquals(expTitle, title);
	}

	public void verifyFirstname(String fName) {
		String text = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		Assert.assertEquals(text, fName);
	}
	public LoginPage clickLogout() {
		driver.findElement(By.linkText("Logout"));
		return new LoginPage(driver);
		
	}
	
	public DuplicatePage clickDuplicate() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
		return new DuplicatePage(driver);
	}
}
