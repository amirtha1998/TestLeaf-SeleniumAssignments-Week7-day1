package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class DeletePage extends ProjectSpecificationMethods{

	public DeletePage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public MyLeads clickDelete() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
		return new MyLeads(driver);

	}

}
