package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class CreateLead extends ProjectSpecificationMethods{

	public CreateLead(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public CreateLead enterFirstname(String fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
				return this;
	}

	public CreateLead enterLastname(String lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;
	}

	public CreateLead enterCompanyname(String cname) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		return this;
}
	public CreateLead enterDepartmentname(String dName) {
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(dName);
		return this;

	}
	
	public ViewLead clickCreateLeadButton() {
		driver.findElement(By.name("submitButton")).click();		
		return new ViewLead(driver);
	}
	
}
