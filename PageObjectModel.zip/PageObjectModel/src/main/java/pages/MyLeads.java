package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificationMethods;

public class MyLeads extends ProjectSpecificationMethods{

	public MyLeads(ChromeDriver driver) {
		this.driver = driver;
	}
	public CreateLead clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLead(driver);

	}
	
	public FindLeads clickFindLead() {
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeads(driver);

	}
	
	
	String expTitle = "My Leads | opentaps CRM";
		
	public MyLeads verifyDelete() {
		String title = driver.getTitle();
		Assert.assertEquals(expTitle, title);
		return new MyLeads(driver);
	
	}
}
