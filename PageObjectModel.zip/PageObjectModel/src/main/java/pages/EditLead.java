package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class EditLead extends ProjectSpecificationMethods{
	
	public EditLead(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EditLead updateCompanyName(String cName) {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
	driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(cName);
	return new EditLead(driver);
	}
	
	public ViewLead clickOnSubmit() {
	driver.findElement(By.name("submitButton")).click();
	return new ViewLead(driver);
	}
}
