package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificationMethods;

public class ViewContact extends ProjectSpecificationMethods{

	public ViewContact(ChromeDriver driver) {
		this.driver = driver;
		
	}
	
	String expTitle = "View Contact | opentaps CRM";
	public void verifytheTitle() {
		String title = driver.getTitle();
		Assert.assertEquals(expTitle, title);
	}


}
