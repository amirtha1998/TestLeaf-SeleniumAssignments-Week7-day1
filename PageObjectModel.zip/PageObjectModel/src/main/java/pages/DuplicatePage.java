package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class DuplicatePage extends ProjectSpecificationMethods{

	public DuplicatePage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public DuplicatePage typeCompanyName() {
	 driver.findElement(By.id("createLeadForm_companyName")).clear();
     driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Test Leaf");
	return this;
	}
	
	public DuplicatePage typeFirstName() {
     driver.findElement(By.id("createLeadForm_firstName")).clear();
     driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Amirtha");
	return this;
		
	}
	
	public ViewLead clickSubmit() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLead(driver);
	}
}
