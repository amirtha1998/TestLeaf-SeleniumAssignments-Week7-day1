package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificationMethods;

public class CreateContactPage extends ProjectSpecificationMethods{

	public CreateContactPage(ChromeDriver driver) {
		this.driver = driver;
	
	}
	
	public CreateContactPage typeFirstName(String fName) {
		driver.findElement(By.id("firstNameField")).sendKeys(fName);
		return new CreateContactPage(driver);

	}

	public CreateContactPage typeLastName(String lName) {
		driver.findElement(By.id("lastNameField")).sendKeys(lName);
		return new CreateContactPage(driver);
	}
	
	public CreateContactPage typeDepartmentName(String dName) {
		driver.findElement(By.xpath("//input[@id='createContactForm_departmentName']")).sendKeys(dName);
		return new CreateContactPage(driver);
	}
	
	public CreateContactPage typeDescription(String description) {
	driver.findElement(By.id("createContactForm_description")).sendKeys(description);
	return new CreateContactPage(driver);

	}
	
	public ViewContact submitButton() {
	driver.findElement(By.name("submitButton")).click();
	return new ViewContact(driver);
	}
}
